<?php
	require 'utilisateur.php';
	$util= new Utilisateur();

	try {
			$DB = new PDO ('mysql:host=localhost;dbname=forum', 'root','');
		}
		catch(PDOException $e) { // msg erreur
			echo "La base de données n'est pas disponible, merci de réessayer plus tard.";
		}

	$stmt = $DB->prepare('SELECT COUNT(*) FROM membres WHERE user = $u');
	$stmt->execute(array($util));

	if ($stmt->fetchColumn() != 0) {
		
		echo "Pas de compte, veuillez vous inscrire.";
		echo "<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js\" > </script>
		<script type=\"text/javascript\">
				function(){
					$(body.this).css(
					{
						'backgroundColor':'red'
					}
								);

				}
			);
				
	</script>" 
		}

	else () {
		 echo "Vous etes connectés.";
		 echo "<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js\" > </script>
		<script type=\"text/javascript\">
				function(){
					$(body.this).css(
					{
						'backgroundColor':'green'
					}
								);

				}
			);
				
	</script>" 
			}
 ?>	