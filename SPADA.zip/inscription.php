<?php
require 'utilisateur.php';
$newutil= new Utilisateur();
try {
			$DB = new PDO ('mysql:host=localhost;dbname=forum', 'root','');
		}
		catch(PDOException $e) { // msg erreur
			echo "La base de données n'est pas disponible, merci de réessayer plus tard.";
		}

	$sqlajoutbdd = $DB->prepare('INSERT INTO membres (user, pass, mail) VALUE (:$u, :$p, :$m)');
	$sqlajoutbdd->execute($newutil);
?>