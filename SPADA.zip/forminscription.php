<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form action="inscription.php" method="POST">
	<p>Veuillez vous inscrire ci dessous :</p>
	<p>
	    Username : <input type="text" name="user" />
	    Password : <input type="text" name="pass" />
	    Mail : <input type="text" name="mail" />
	    <input type="submit" value="Login" />
	    
	</p>
</form>
</body>
</html>