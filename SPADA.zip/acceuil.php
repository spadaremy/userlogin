<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form action="connexion.php" method="POST">
	<p>
	    <input type="text" name="user" />
	    <input type="text" name="pass" />
	    <input type="submit" value="Login" />
	    <a href="forminscription.php">Pas encore inscrit ?</a>
	</p>
</form>
</body>
</html>