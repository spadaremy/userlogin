<?php

class Utilisateur{

    // Propriétés
    public $user;
    $u = $_POST['user'];
    public $pass;
    $p = $_POST['pass'];
    public $mail; 
    $m = $_POST['mail'];
}

?>